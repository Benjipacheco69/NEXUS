# NEXUS WinForms — actualización visual

Esta actualización se concentra en la presentación de Windows Forms. No modifica reglas de combate, exploración, inventario, misiones ni agrega persistencia/SQL.

## Cambios visuales
- Menú principal con fondo espacial generado por dibujo (degradado, retícula técnica, estrellas y arcos luminosos).
- Jerarquía visual renovada para el título, subtítulo, descripción y acciones principales.
- Botones personalizados con esquinas redondeadas, degradado, borde cian y estado hover.
- Paleta oscura azul petróleo/cian mantenida en el resto de pantallas.
- Ventana maximizada al iniciar para aprovechar mejor la pantalla.

## Música
No se incluye música de Dota 2 ni ninguna pista comercial protegida. Para una ambientación similar en términos generales, se recomienda una pieza original de fantasía oscura/ciencia ficción: orquesta cinematográfica, coros ambientales, percusión profunda y sintetizadores. Puede incorporarse posteriormente como archivo WAV con licencia o creado específicamente para NEXUS.

La lógica del juego y SQL quedan fuera de esta actualización.
