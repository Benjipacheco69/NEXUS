# NEXUS WinForms — etapa de interfaz y juego local

Esta etapa implementa la experiencia jugable en memoria. **No incluye SQL Server, consultas, repositorios ni persistencia.**

## Ejecutar
1. Abrir `POO Nexus.slnx` en Visual Studio 2022 actualizado con soporte para .NET 10.
2. Establecer `Nexus.WinForms` como proyecto de inicio.
3. Ejecutar con F5.

## Incluye
- Menú principal y registro del cadete.
- Validación: edad mínima 18, energía mínima 30 y estabilidad mínima 40.
- Mapa 3×3, movimiento cardinal y zonas visitadas.
- Eventos aleatorios, objetos e inventario con capacidad máxima de 8.
- Recursos, misión de cuatro objetivos, combate, análisis y extracción.
- Panel de registro de eventos e interfaz temática NEXUS.

## Reglas base trasladadas
- Movimiento: energía -5 y estabilidad -2.
- Analizar anomalía: energía -8; pistas IRIS hasta 3.
- Descansar: +15 energía, máximo 100.
- Criatura: 30 energía / 10 ataque / 20 XP.
- Robot centinela: 30 energía / 6 ataque / recibe la mitad del daño / 30 XP.
- Guardián: 50 energía / 10 ataque.
- Escapar: energía -5 y probabilidad 50%.
- Escudo absorbe daño antes que la energía.
- Misión: llegar a (2,2), conseguir núcleo, sobrevivir al Guardián y volver a (0,0); recompensa 100 XP y módulo +10 ataque.

## Nota técnica
La versión original de consola se conserva en `POO Nexus/`. La interfaz gráfica utiliza una sesión de juego local propia para no depender de `Console.ReadLine` ni `Console.WriteLine`. En una siguiente iteración se puede extraer el dominio a una biblioteca compartida y eliminar duplicación, preservando las reglas. El estado se pierde al cerrar la aplicación, tal como ocurre en la versión actual sin persistencia.
