using System.Drawing.Drawing2D;

namespace Nexus.WinForms;

public partial class Form1 : Form
{
    private readonly Color bg = Color.FromArgb(9, 17, 29);
    private readonly Color panel = Color.FromArgb(17, 31, 49);
    private readonly Color panel2 = Color.FromArgb(24, 43, 65);
    private readonly Color cyan = Color.FromArgb(48, 210, 238);
    private readonly Color muted = Color.FromArgb(151, 174, 194);
    private readonly Color red = Color.FromArgb(255, 91, 105);
    private readonly Font uiFont = new("Segoe UI", 10F);
    private GameSession? game;
    private Panel root = null!;
    private Panel mapPanel = null!, combatPanel = null!;
    private Label lblEnergy = null!, lblStability = null!, lblAttack = null!, lblShield = null!, lblXp = null!, lblClues = null!, lblZones = null!, lblCadet = null!;
    private ProgressBar energyBar = null!, stabilityBar = null!, enemyBar = null!;
    private Label lblEnemy = null!, lblEnemyInfo = null!;
    private TextBox log = null!;
    private Button[] mapButtons = new Button[9];
    private Label[] missionLabels = new Label[4];
    private Button[] moveButtons = new Button[4];
    private Button btnAnalyze = null!, btnRest = null!, btnInventory = null!, btnAnalyzeEntity = null!, btnAttack = null!, btnEscape = null!, btnUse = null!;
    private bool ended;

    public Form1()
    {
        InitializeComponent();
        Text = "NEXUS H3/v2.0";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1100, 720);
        Size = new Size(1440, 900);
        BackColor = bg;
        ForeColor = Color.White;
        Font = uiFont;
        DoubleBuffered = true;
        WindowState = FormWindowState.Maximized;
        BuildRoot();
        ShowMainMenu();
    }

    private void BuildRoot()
    {
        root = new Panel { Dock = DockStyle.Fill, BackColor = bg, Padding = Padding.Empty };
        Controls.Add(root);
    }

    private void ClearRoot()
    {
        root.Controls.Clear();
        root.SuspendLayout();
    }

    private Label Label(string text, int size = 10, Color? color = null, bool bold = false)
        => new() { Text = text, AutoSize = true, ForeColor = color ?? Color.White, Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular) };

    private Button MakeButton(string text, Action action, bool primary = false)
    {
        var b = new NexusButton(primary)
        {
            Text = text, Height = 48, ForeColor = Color.White,
            Font = new Font("Segoe UI Semibold", 10F), Cursor = Cursors.Hand,
            Dock = DockStyle.None, Margin = new Padding(0, 6, 0, 6),
            BackColor = primary ? Color.FromArgb(5, 116, 145) : panel2,
            FlatStyle = FlatStyle.Flat
        };
        b.Click += (_, _) => action();
        return b;
    }

    private Panel Card(string title, Control content, int width = 300)
    {
        var p = new Panel { BackColor = panel, Padding = new Padding(16), Width = width, AutoSize = false };
        var t = Label(title.ToUpperInvariant(), 10, cyan, true);
        t.Dock = DockStyle.Top;
        t.Height = 26;
        content.Dock = DockStyle.Fill;
        p.Controls.Add(content); p.Controls.Add(t);
        return p;
    }

    private void ShowMainMenu()
    {
        ClearRoot();
        var scene = new NexusBackdrop { Dock = DockStyle.Fill };
        var content = new Panel { Size = new Size(720, 650), BackColor = Color.Transparent, Anchor = AnchorStyles.None };
        void CenterContent()
        {
            content.Location = new Point(Math.Max(20, (scene.ClientSize.Width-content.Width)/2), Math.Max(10, (scene.ClientSize.Height-content.Height)/2));
        }
        scene.Resize += (_, _) => CenterContent();
        CenterContent();

        var top = Label("N E X U S", 48, Color.White, true);
        top.Font = new Font("Bahnschrift SemiBold", 48, FontStyle.Bold);
        top.Location = new Point(105, 35);
        var glow = Label("N E X U S", 48, cyan, true);
        glow.Font = new Font("Bahnschrift SemiBold", 48, FontStyle.Bold);
        glow.Location = new Point(102, 32);
        var eyebrow = Label("NEXUS SYSTEMS  /  PROTOCOLO H3", 10, cyan, true);
        eyebrow.Location = new Point(111, 112);
        var sub = Label("LA REALIDAD ES SOLO EL PRIMER LÍMITE", 12, Color.FromArgb(195, 211, 226), true);
        sub.Location = new Point(111, 150);
        var desc = Label("Una señal desconocida atraviesa las capas de la simulación.\nTu misión: entrar, descubrir su origen y regresar con vida.", 11, muted);
        desc.Location = new Point(111, 194);
        var line = new Panel { BackColor = cyan, Location = new Point(111, 260), Size = new Size(470, 2) };
        var start = MakeButton("INICIAR NUEVA INMERSIÓN     ›", ShowRegistration, true);
        start.Location = new Point(111, 300); start.Size = new Size(470, 58);
        var continueButton = MakeButton("CONTINUAR  ·  SESIÓN NO DISPONIBLE", () => MessageBox.Show("No existe una partida guardada. La persistencia se incorporará en una etapa posterior.", "NEXUS // SISTEMA", MessageBoxButtons.OK, MessageBoxIcon.Information));
        continueButton.Location = new Point(111, 372); continueButton.Size = new Size(470, 48);
        var quit = MakeButton("CERRAR SISTEMA", Close);
        quit.Location = new Point(111, 434); quit.Size = new Size(470, 48);
        var footer = Label("H3 / v2.0     •     SESIÓN LOCAL     •     IRIS ONLINE", 9, Color.FromArgb(112, 143, 167), true);
        footer.Location = new Point(111, 520);
        var side = new Panel { Location = new Point(615, 303), Size = new Size(3, 185), BackColor = Color.FromArgb(35, 84, 108) };
        content.Controls.AddRange(new Control[] { glow, top, eyebrow, sub, desc, line, start, continueButton, quit, footer, side });
        scene.Controls.Add(content);
        root.Controls.Add(scene);
        root.ResumeLayout();
    }

    private void ShowRegistration()
    {
        ClearRoot();
        var box = new Panel { Size = new Size(650, 600), BackColor = Color.FromArgb(15, 29, 46), Padding = new Padding(34), Anchor = AnchorStyles.None };
        box.Location = new Point((ClientSize.Width-box.Width)/2, (ClientSize.Height-box.Height)/2);
        var title = Label("IDENTIFICACIÓN DEL CADETE", 22, cyan, true); title.Location = new Point(34, 30);
        var intro = Label("Complete los parámetros biométricos para autorizar la inmersión.", 10, muted); intro.Location = new Point(36, 78);
        var name = new TextBox { Location = new Point(36, 145), Width = 560, Height = 34, Font = new Font("Segoe UI", 12), BackColor = panel2, ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle, Text = "Cadete" };
        var age = Numeric(20, 18, 99, 36, 240);
        var energy = Numeric(80, 30, 100, 36, 340);
        var stability = Numeric(90, 40, 100, 36, 440);
        AddField(box, "NOMBRE / IDENTIFICADOR", name, 112);
        AddField(box, "EDAD (MÍNIMO 18)", age, 205);
        AddField(box, "ENERGÍA INICIAL (30–100)", energy, 305);
        AddField(box, "ESTABILIDAD INICIAL (40–100)", stability, 405);
        var warning = Label("Los valores inferiores a los mínimos rechazan la autorización.", 9, muted); warning.Location = new Point(36, 505);
        var launch = MakeButton("AUTORIZAR E INICIAR", () =>
        {
            if (string.IsNullOrWhiteSpace(name.Text)) { MessageBox.Show("Ingrese un nombre."); return; }
            game = new GameSession(name.Text.Trim(), (int)age.Value, (int)energy.Value, (int)stability.Value);
            ended = false; ShowGame(); AddLog($"[IRIS] Inmersión autorizada. Bienvenido, {game.Name}.");
            AddLog("[SISTEMA] Equipo inicial: célula de energía y analizador.");
        }, true);
        launch.Location = new Point(36, 545); launch.Width = 270;
        var back = MakeButton("VOLVER", ShowMainMenu); back.Location = new Point(320, 545); back.Width = 150;
        box.Controls.AddRange(new Control[] { title, intro, name, age, energy, stability, warning, launch, back });
        root.Controls.Add(box); root.ResumeLayout();
    }

    private NumericUpDown Numeric(int value, int min, int max, int x, int y)
        => new() { Value=value, Minimum=min, Maximum=max, Location=new Point(x,y), Width=120, BackColor=panel2, ForeColor=Color.White, Font=new Font("Segoe UI",12), BorderStyle=BorderStyle.FixedSingle };

    private void AddField(Control parent, string text, Control input, int y)
    {
        var l = Label(text, 9, muted, true); l.Location = new Point(36, y);
        input.Location = new Point(36, y+25); parent.Controls.Add(l); parent.Controls.Add(input);
    }

    private void ShowGame()
    {
        ClearRoot();
        var header = new Panel { Dock=DockStyle.Top, Height=82, BackColor=Color.FromArgb(12, 25, 41), Padding=new Padding(18) };
        var logo = Label("NEXUS", 23, cyan, true); logo.Location = new Point(18, 12);
        var subtitle = Label("H3 / v2.0     •     EXPLORACIÓN DE REALIDAD", 9, muted, true); subtitle.Location = new Point(150, 27);
        lblCadet = Label("CADETE", 10, Color.White, true); lblCadet.Anchor=AnchorStyles.Top|AnchorStyles.Right; lblCadet.Location=new Point(1050,27);
        header.Controls.AddRange(new Control[]{logo,subtitle,lblCadet});
        var body = new TableLayoutPanel { Dock=DockStyle.Fill, ColumnCount=3, RowCount=1, Padding=new Padding(0,18,0,0), BackColor=bg };
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48));
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27));
        var left = new FlowLayoutPanel { Dock=DockStyle.Fill, FlowDirection=FlowDirection.TopDown, WrapContents=false, AutoScroll=true, BackColor=bg, Padding=new Padding(0,0,12,0) };
        var center = new Panel { Dock=DockStyle.Fill, BackColor=bg, Padding=new Padding(8,0,8,0) };
        var right = new FlowLayoutPanel { Dock=DockStyle.Fill, FlowDirection=FlowDirection.TopDown, WrapContents=false, AutoScroll=true, BackColor=bg, Padding=new Padding(12,0,0,0) };
        body.Controls.Add(left,0,0); body.Controls.Add(center,1,0); body.Controls.Add(right,2,0);
        root.Controls.Add(body); root.Controls.Add(header);
        BuildStatus(left); BuildMap(center); BuildMission(right); BuildCombat(right);
        UpdateGameUI(); root.ResumeLayout();
    }

    private void BuildStatus(FlowLayoutPanel host)
    {
        var p = new Panel { Width=280, Height=300, BackColor=Color.FromArgb(15, 29, 46), Padding=new Padding(14), Margin=new Padding(0,0,0,12) };
        var title=Label("ESTADO DEL CADETE",11,cyan,true); title.Location=new Point(14,12);
        lblEnergy=Label("ENERGÍA  0/100",9,Color.White,true); lblEnergy.Location=new Point(14,55);
        energyBar=Progress(); energyBar.Location=new Point(14,78); energyBar.Width=245;
        lblStability=Label("ESTABILIDAD  0/100",9,Color.White,true); lblStability.Location=new Point(14,116);
        stabilityBar=Progress(); stabilityBar.Location=new Point(14,139); stabilityBar.Width=245;
        lblAttack=Label("ATAQUE: 10",10); lblAttack.Location=new Point(14,184);
        lblShield=Label("ESCUDO: 0",10); lblShield.Location=new Point(14,210);
        lblXp=Label("XP: 0",10); lblXp.Location=new Point(14,236);
        lblClues=Label("PISTAS IRIS: 0/3",10); lblClues.Location=new Point(14,262);
        p.Controls.AddRange(new Control[]{title,lblEnergy,energyBar,lblStability,stabilityBar,lblAttack,lblShield,lblXp,lblClues});
        host.Controls.Add(p);
        var actions = new Panel { Width=280, Height=285, BackColor=Color.FromArgb(15, 29, 46), Padding=new Padding(14), Margin=new Padding(0,0,0,12) };
        var at=Label("ACCIONES",11,cyan,true); at.Location=new Point(14,12); actions.Controls.Add(at);
        btnAnalyze=MakeButton("ANALIZAR ANOMALÍA", ()=>Act(()=>game!.AnalyzeAnomaly())); btnAnalyze.Location=new Point(14,45); btnAnalyze.Size=new Size(245,40);
        btnRest=MakeButton("RECUPERAR ENERGÍA", ()=>Act(()=>game!.Rest())); btnRest.Location=new Point(14,93); btnRest.Size=new Size(245,40);
        btnInventory=MakeButton("ABRIR INVENTARIO", ShowInventory); btnInventory.Location=new Point(14,141); btnInventory.Size=new Size(245,40);
        var mission=MakeButton("CONSULTAR MISIÓN", ()=>MessageBox.Show(string.Join(Environment.NewLine, game!.Objectives.Select((o,i)=>$"{(game.Done[i]?"[X]":"[ ]")} {o}")), "MISIÓN: LA ANOMALÍA PERDIDA")); mission.Location=new Point(14,189); mission.Size=new Size(245,40);
        actions.Controls.AddRange(new Control[]{btnAnalyze,btnRest,btnInventory,mission}); host.Controls.Add(actions);
    }
    private ProgressBar Progress() => new(){Minimum=0,Maximum=100,Style=ProgressBarStyle.Continuous,Height=13,ForeColor=cyan,BackColor=panel2};

    private void BuildMap(Panel host)
    {
        var title=Label("MAPA DE REALIDADES",15,cyan,true); title.Location=new Point(10,8); host.Controls.Add(title);
        var legend=Label("J jugador  •  E extracción  •  X zona visitada  •  — desconocida",9,muted); legend.Location=new Point(12,39); host.Controls.Add(legend);
        mapPanel=new Panel { Location=new Point(10,78), Size=new Size(510,430), BackColor=panel, Padding=new Padding(18) }; host.Controls.Add(mapPanel);
        var grid=new TableLayoutPanel { Dock=DockStyle.Fill, RowCount=3, ColumnCount=3, BackColor=panel, Padding=new Padding(8) };
        for(int i=0;i<3;i++){grid.RowStyles.Add(new RowStyle(SizeType.Percent,33.33f));grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,33.33f));}
        for(int i=0;i<9;i++)
        {
            int index=i; var b=new Button{Dock=DockStyle.Fill,Margin=new Padding(5),FlatStyle=FlatStyle.Flat,BackColor=panel2,ForeColor=muted,Font=new Font("Segoe UI",18,FontStyle.Bold),Enabled=false};
            b.FlatAppearance.BorderColor=Color.FromArgb(54,82,108); b.Text="—"; mapButtons[i]=b; grid.Controls.Add(b,i%3,i/3);
        }
        mapPanel.Controls.Add(grid);
        var moveTitle=Label("DESPLAZAMIENTO TÁCTICO",10,cyan,true); moveTitle.Location=new Point(10,530); host.Controls.Add(moveTitle);
        var movePanel=new Panel{Location=new Point(10,555),Size=new Size(510,150),BackColor=panel};
        moveButtons[0]=MoveButton("NORTE", "N", 180, 5);
        moveButtons[1]=MoveButton("OESTE", "O", 45, 55);
        moveButtons[2]=MoveButton("SUR", "S", 180, 55);
        moveButtons[3]=MoveButton("ESTE", "E", 315, 55);
        movePanel.Controls.AddRange(moveButtons); host.Controls.Add(movePanel);
        var status=Label("SECTOR 3×3  //  EXTRACCIÓN (0,0)  //  ANOMALÍA (2,2)",9,muted); status.Location=new Point(12,720); host.Controls.Add(status);
    }
    private Button MoveButton(string text,string dir,int x,int y)
    {
        var b=MakeButton(text,()=>Act(()=>game!.Move(dir))); b.Location=new Point(x,y); b.Size=new Size(125,42); return b;
    }

    private void BuildMission(FlowLayoutPanel host)
    {
        var p=new Panel{Width=300,Height=230,BackColor=panel,Padding=new Padding(14),Margin=new Padding(0,0,0,12)};
        var title=Label("MISIÓN // LA ANOMALÍA PERDIDA",10,cyan,true); title.Location=new Point(14,12); p.Controls.Add(title);
        string[] obj={"Llegar a la zona de anomalía","Encontrar el núcleo energético","Sobrevivir al encuentro con la entidad","Regresar al punto de extracción"};
        for(int i=0;i<4;i++){missionLabels[i]=Label("○ "+obj[i],9,muted);missionLabels[i].MaximumSize=new Size(265,0);missionLabels[i].Location=new Point(14,55+i*39);p.Controls.Add(missionLabels[i]);}
        host.Controls.Add(p);
        var iris=new Panel{Width=300,Height=120,BackColor=panel,Padding=new Padding(14),Margin=new Padding(0,0,0,12)};
        var ir=Label("CANAL IRIS",10,cyan,true); ir.Location=new Point(14,12);
        var tx=Label("Sistema de asistencia activo.\nExplora las zonas y completa los objetivos.",9,muted);tx.Location=new Point(14,42);
        iris.Controls.AddRange(new Control[]{ir,tx});host.Controls.Add(iris);
    }

    private void BuildCombat(FlowLayoutPanel host)
    {
        combatPanel=new Panel{Width=300,Height=300,BackColor=panel,Padding=new Padding(14),Margin=new Padding(0,0,0,12)};
        var title=Label("ENCUENTRO",11,red,true); title.Location=new Point(14,12);
        lblEnemy=Label("SIN ENTIDAD DETECTADA",10,Color.White,true);lblEnemy.Location=new Point(14,48);
        enemyBar=Progress();enemyBar.Location=new Point(14,78);enemyBar.Width=260;
        lblEnemyInfo=Label("Energía: —   Ataque: —",9,muted);lblEnemyInfo.Location=new Point(14,102);
        btnAttack=MakeButton("ATACAR",()=>Act(()=>game!.AttackEnemy()),true);btnAttack.Location=new Point(14,140);btnAttack.Size=new Size(260,38);
        btnUse=MakeButton("USAR OBJETO",ShowInventory);btnUse.Location=new Point(14,184);btnUse.Size=new Size(260,38);
        btnAnalyzeEntity=MakeButton("ANALIZAR ENTIDAD",()=>Act(()=>AddLog(game!.AnalyzeEntity())));btnAnalyzeEntity.Location=new Point(14,228);btnAnalyzeEntity.Size=new Size(260,38);
        btnEscape=MakeButton("INTENTAR ESCAPAR",()=>Act(()=>game!.Escape()));btnEscape.Location=new Point(14,272);btnEscape.Size=new Size(260,38);
        combatPanel.Controls.AddRange(new Control[]{title,lblEnemy,enemyBar,lblEnemyInfo,btnAttack,btnUse,btnAnalyzeEntity,btnEscape});
        combatPanel.Height=325;host.Controls.Add(combatPanel);
        var logPanel=new Panel{Width=300,Height=260,BackColor=panel,Padding=new Padding(12)};
        var lt=Label("REGISTRO DE EVENTOS",10,cyan,true);lt.Dock=DockStyle.Top;
        log=new TextBox{Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,BorderStyle=BorderStyle.None,BackColor=panel,ForeColor=Color.FromArgb(190,210,225),Font=new Font("Consolas",9),Dock=DockStyle.Fill};
        logPanel.Controls.Add(log);logPanel.Controls.Add(lt);host.Controls.Add(logPanel);
    }

    private void AddLog(string message)
    {
        if(log is null || log.IsDisposed) return;
        log.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}{Environment.NewLine}");
    }

    private void Act(Action action)
    {
        if(game is null || ended) return;
        try { action(); AddLog(game.LastMessage); UpdateGameUI(); CheckEnd(); }
        catch(Exception ex){AddLog("[ERROR] "+ex.Message);}
    }

    private void UpdateGameUI()
    {
        if(game is null || lblEnergy is null) return;
        lblCadet.Text="CADETE // "+game.Name;
        lblEnergy.Text=$"ENERGÍA  {game.Energy}/100"; energyBar.Value=Math.Clamp(game.Energy,0,100);
        lblStability.Text=$"ESTABILIDAD  {game.Stability}/100"; stabilityBar.Value=Math.Clamp(game.Stability,0,100);
        lblAttack.Text=$"ATAQUE: {game.Attack}";lblShield.Text=$"ESCUDO: {game.Shield}";
        lblXp.Text=$"XP: {game.Xp}  •  ZONAS: {game.Zones}";
        lblClues.Text=$"PISTAS IRIS: {game.Clues}/3";
        for(int i=0;i<9;i++)
        {
            int r=i/3,c=i%3; bool here=game.Row==r&&game.Col==c;
            char cell=here?'J':(r==0&&c==0?'E':game.Visited[r,c]?'X':'—');
            mapButtons[i].Text=cell.ToString();
            mapButtons[i].BackColor=here?Color.FromArgb(5,105,132):cell=='E'?Color.FromArgb(38,70,91):cell=='X'?Color.FromArgb(32,54,73):panel2;
            mapButtons[i].ForeColor=here?Color.White:cell=='E'?cyan:muted;
            mapButtons[i].FlatAppearance.BorderColor=here?cyan:Color.FromArgb(54,82,108);
        }
        for(int i=0;i<4;i++){missionLabels[i].Text=(game.Done[i]?"✓ ":"○ ")+game.Objectives[i];missionLabels[i].ForeColor=game.Done[i]?Color.LightGreen:muted;}
        bool encounter=game.Enemy is not null;
        combatPanel.Visible=encounter;
        foreach(var b in moveButtons)b.Enabled=!encounter;
        btnAnalyze.Enabled=!encounter;btnRest.Enabled=!encounter;
        if(encounter)
        {
            lblEnemy.Text=game.Enemy!.Name;enemyBar.Value=Math.Clamp(game.Enemy.Energy*100/game.Enemy.MaxEnergy,0,100);
            lblEnemyInfo.Text=$"ENERGÍA: {game.Enemy.Energy}/{game.Enemy.MaxEnergy}   ATAQUE: {game.Enemy.Attack}";
        }
        else {lblEnemy.Text="SIN ENTIDAD DETECTADA";enemyBar.Value=0;lblEnemyInfo.Text="Exploración libre";}
    }

    private void ShowInventory()
    {
        if(game is null)return;
        using var f=new Form{Text="INVENTARIO DEL CADETE",Size=new Size(560,440),StartPosition=FormStartPosition.CenterParent,BackColor=bg,ForeColor=Color.White,Font=uiFont,FormBorderStyle=FormBorderStyle.FixedDialog,MaximizeBox=false,MinimizeBox=false};
        var list=new ListBox{Location=new Point(20,55),Size=new Size(500,245),BackColor=panel,ForeColor=Color.White,Font=new Font("Segoe UI",11),BorderStyle=BorderStyle.FixedSingle};
        foreach(var item in game.Items)list.Items.Add(item.Description);
        var title=Label($"INVENTARIO  {game.Items.Count}/8",13,cyan,true);title.Location=new Point(20,18);
        var use=MakeButton("USAR OBJETO SELECCIONADO",()=>{if(list.SelectedIndex<0){MessageBox.Show("Selecciona un objeto.");return;} int idx=list.SelectedIndex; if(game.UseItem(idx,out var msg)){MessageBox.Show(msg);f.DialogResult=DialogResult.OK;f.Close();}else MessageBox.Show(msg);},true);
        use.Location=new Point(20,320);use.Size=new Size(280,42);
        var close=MakeButton("CERRAR",f.Close);close.Location=new Point(320,320);close.Size=new Size(200,42);
        f.Controls.AddRange(new Control[]{title,list,use,close});
        if(f.ShowDialog(this)==DialogResult.OK){UpdateGameUI();CheckEnd();}
    }

    private void CheckEnd()
    {
        if(game is null||ended)return;
        if(game.Done.All(x=>x)){ended=true;MessageBox.Show($"MISIÓN COMPLETADA, {game.Name}.\n+100 XP\n+1 Módulo desconocido (+10 ataque)","NEXUS // EXTRACCIÓN",MessageBoxButtons.OK,MessageBoxIcon.Information);ShowResult(true);}
        else if(game.Energy<=0||game.Stability<=0){ended=true;ShowResult(false);}
    }

    private void ShowResult(bool victory)
    {
        ClearRoot();
        var p=new Panel{Size=new Size(650,470),BackColor=panel,Padding=new Padding(35),Anchor=AnchorStyles.None};
        p.Location=new Point((ClientSize.Width-p.Width)/2,(ClientSize.Height-p.Height)/2);
        var title=Label(victory?"MISIÓN COMPLETADA":"INMERSIÓN FINALIZADA",25,victory?cyan:red,true);title.Location=new Point(35,35);
        var msg=Label(victory?"Has regresado al punto de extracción.":"El cadete no puede continuar la inmersión.",11,muted);msg.Location=new Point(38,100);
        var stats=Label($"CADETE: {game!.Name}\nENERGÍA: {game.Energy}\nESTABILIDAD: {game.Stability}\nATAQUE: {game.Attack}\nXP: {game.Xp}\nZONAS EXPLORADAS: {game.Zones}",12,Color.White);stats.Location=new Point(38,160);
        var menu=MakeButton("VOLVER AL MENÚ",ShowMainMenu,true);menu.Location=new Point(38,350);menu.Size=new Size(250,45);
        p.Controls.AddRange(new Control[]{title,msg,stats,menu});root.Controls.Add(p);root.ResumeLayout();
    }
}


internal sealed class NexusButton : Button
{
    private readonly bool primary;
    public NexusButton(bool isPrimary) { primary = isPrimary; SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true); }
    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var rect = ClientRectangle; rect.Inflate(-1, -1);
        var radius = 10;
        using var path = Rounded(rect, radius);
        var baseColor = Enabled ? (primary ? Color.FromArgb(5, 105, 133) : Color.FromArgb(24, 43, 65)) : Color.FromArgb(30, 42, 55);
        if (ClientRectangle.Contains(PointToClient(Cursor.Position)) && Enabled)
            baseColor = primary ? Color.FromArgb(8, 145, 177) : Color.FromArgb(37, 67, 91);
        using var brush = new LinearGradientBrush(rect, baseColor, Color.FromArgb(Math.Min(255, baseColor.R+8), Math.Min(255, baseColor.G+13), Math.Min(255, baseColor.B+18)), LinearGradientMode.Vertical);
        e.Graphics.FillPath(brush, path);
        using var pen = new Pen(primary ? Color.FromArgb(65, 218, 239) : Color.FromArgb(55, 91, 119), 1.2f);
        e.Graphics.DrawPath(pen, path);
        TextRenderer.DrawText(e.Graphics, Text, Font, rect, Enabled ? ForeColor : Color.FromArgb(125, 143, 158), TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
    }
    private static GraphicsPath Rounded(Rectangle r, int radius)
    {
        var p = new GraphicsPath(); int d = radius*2;
        p.AddArc(r.X,r.Y,d,d,180,90); p.AddArc(r.Right-d,r.Y,d,d,270,90);
        p.AddArc(r.Right-d,r.Bottom-d,d,d,0,90); p.AddArc(r.X,r.Bottom-d,d,d,90,90); p.CloseFigure(); return p;
    }
}

internal sealed class NexusBackdrop : Panel
{
    private readonly PointF[] stars = Enumerable.Range(0, 95).Select(i => new PointF((i*97 % 997)/997f, (i*193 % 991)/991f)).ToArray();
    public NexusBackdrop() { DoubleBuffered = true; ResizeRedraw = true; }
    protected override void OnPaintBackground(PaintEventArgs e)
    {
        using var brush = new LinearGradientBrush(ClientRectangle, Color.FromArgb(5, 11, 21), Color.FromArgb(13, 35, 54), 35f);
        e.Graphics.FillRectangle(brush, ClientRectangle);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        using var gridPen = new Pen(Color.FromArgb(18, 54, 81), 1);
        for (int x=0; x<Width; x+=48) e.Graphics.DrawLine(gridPen,x,0,x,Height);
        for (int y=0; y<Height; y+=48) e.Graphics.DrawLine(gridPen,0,y,Width,y);
        foreach (var star in stars)
        {
            float x=star.X*Width, y=star.Y*Height;
            using var dot = new SolidBrush(Color.FromArgb(75, 102, 160, 188));
            e.Graphics.FillEllipse(dot,x,y,2,2);
        }
        using var accent = new Pen(Color.FromArgb(42, 48, 193, 218), 2);
        e.Graphics.DrawArc(accent, Width-420, -180, 560, 560, 30, 220);
        using var accent2 = new Pen(Color.FromArgb(22, 48, 193, 218), 1);
        e.Graphics.DrawArc(accent2, Width-470, -230, 660, 660, 30, 220);
    }
}

internal sealed class GameSession
{
    public sealed class Item(string name,string kind,int value)
    {
        public string Name=name; public string Kind=kind; public int Value=value;
        public string Description => Kind switch {"cell"=>$"{Name}  (+{Value} energía)","shield"=>$"{Name}  (+{Value} escudo)","attack"=>$"{Name}  (+{Value} ataque)",_=>$"{Name}  (analizador)"};
    }
    public sealed class Foe(string name,int energy,int attack,bool robot,bool guardian)
    {
        public string Name=name; public int Energy=energy; public int MaxEnergy=energy; public int Attack=attack; public bool Robot=robot; public bool Guardian=guardian;
    }
    public string Name{get;} public int Energy{get;private set;} public int Stability{get;private set;} public int Attack{get;private set;}=10;
    public int Shield{get;private set;} public int Xp{get;private set;} public int Zones{get;private set;} public int Clues{get;private set;}
    public int Row{get;private set;} public int Col{get;private set;} public bool[,] Visited{get;}=new bool[3,3];
    public bool[] Done{get;}=new bool[4];
    public string[] Objectives{get;}={"Llegar a la zona de anomalía","Encontrar el núcleo energético","Sobrevivir al encuentro con la entidad","Regresar al punto de extracción"};
    public List<Item> Items{get;}=new(); public Foe? Enemy{get;private set;}
    public string LastMessage { get; private set; } = "Sistema listo.";
    public bool MissionRewarded { get; private set; }
    private readonly Random rng=new(); private bool guardianFight;
    public GameSession(string name,int age,int energy,int stability)
    {
        if(age<18||energy<30||stability<40)throw new ArgumentException("Requisitos: edad >=18, energía >=30 y estabilidad >=40.");
        Name=name;Energy=Math.Min(100,energy);Stability=Math.Min(100,stability);Items.Add(new("Célula de energía","cell",25));Items.Add(new("Analizador","analyzer",0));
    }
    public void Move(string d)
    {
        if(Enemy!=null)throw new InvalidOperationException("No puedes moverte con una entidad cerca.");
        int r=Row,c=Col; if(d=="N")r--;else if(d=="S")r++;else if(d=="E")c++;else if(d=="O")c--;
        if(r<0||r>2||c<0||c>2)throw new InvalidOperationException("No puedes salir del mapa.");
        Row=r;Col=c;Visited[r,c]=true;Energy=Math.Max(0,Energy-5);Stability=Math.Max(0,Stability-2);Zones++; LastMessage=$"Te desplazas a la zona ({r},{c}). Energía -5, estabilidad -2.";
        if(Row==2&&Col==2&&!Done[0])
        {
            Done[0]=true;Done[1]=true;guardianFight=true;Enemy=new("Guardián de la anomalía",50,10,false,true); LastMessage="ANOMALÍA DETECTADA. Encontraste el núcleo energético. ¡El Guardián te ataca!";
            return;
        }
        if(Row==0&&Col==0){if(Done[0]&&Done[1]&&Done[2]){Done[3]=true;if(!MissionRewarded){Xp+=100;if(Items.Count<8)Items.Add(new("Módulo desconocido","attack",10));MissionRewarded=true;}LastMessage="Has regresado al punto de extracción. Misión cumplida: +100 XP y módulo desconocido (+10 ataque)."; }else { LastMessage="Estás en extracción, pero aún faltan objetivos."; throw new InvalidOperationException(LastMessage); } return;}
        ResolveEvent();
    }
    private void ResolveEvent()
    {
        int e=rng.Next(7);
        switch(e)
        {
            case 0:
                int t=rng.Next(4);var item=t switch{0=>new Item("Célula de energía","cell",25),1=>new Item("Escudo","shield",20),2=>new Item("Módulo de ataque","attack",5),_=>new Item("Analizador","analyzer",0)};
                if(Items.Count<8){Items.Add(item);LastMessage=$"OBJETO ENCONTRADO: {item.Name}.";}else LastMessage="Inventario lleno. No puedes guardar más objetos.";break;
            case 1: Enemy=rng.Next(2)==0?new("Robot centinela",30,6,true,false):new("Criatura de la anomalía",30,10,false,false);LastMessage=$"ENTIDAD DETECTADA: {Enemy.Name}.";break;
            case 2: Stability=Math.Max(0,Stability-10);LastMessage="ANOMALÍA: distorsión de realidad. Estabilidad -10.";break;
            case 3: Clues=Math.Min(3,Clues+1);LastMessage=$"Registro de IRIS encontrado. Pistas: {Clues}/3.";break;
            case 4: Energy=Math.Max(0,Energy-10);LastMessage="Fuga en el traje. Energía -10.";break;
            case 5: Energy=Math.Max(0,Energy-5);Stability=Math.Max(0,Stability-5);LastMessage="Sistema dañado: energía -5, estabilidad -5.";break;
            default: LastMessage="No encuentras nada en esta zona.";break;
        }
    }
    public void AnalyzeAnomaly(){if(Enemy!=null)throw new InvalidOperationException("Hay una entidad cerca.");Energy=Math.Max(0,Energy-8);Clues=Math.Min(3,Clues+1);LastMessage=$"Análisis completado. Energía -8. Pistas IRIS: {Clues}/3.";}
    public void Rest(){if(Enemy!=null)throw new InvalidOperationException("No puedes descansar con una entidad cerca.");int before=Energy;Energy=Math.Min(100,Energy+15);LastMessage=$"Recuperaste {Energy-before} de energía."; }
    public bool UseItem(int index,out string message)
    {
        if(index<0||index>=Items.Count){message="Objeto inválido.";return false;}
        var it=Items[index];if(it.Kind=="analyzer"){message="El analizador se utiliza con la acción ANALIZAR ENTIDAD.";return false;}
        switch(it.Kind){case "cell":Energy=Math.Min(100,Energy+it.Value);message=$"Energía recuperada. Total: {Energy}/100.";break;case "shield":Shield+=it.Value;message=$"Escudo activado: {Shield} puntos.";break;default:Attack+=it.Value;message=$"Ataque aumentado a {Attack}.";break;}
        Items.RemoveAt(index);if(Enemy!=null)EnemyReaction();LastMessage=message;return true;
    }
    public void AttackEnemy()
    {
        if(Enemy==null)throw new InvalidOperationException("No hay ninguna entidad para atacar.");
        int damage=Attack;if(Enemy.Robot)damage/=2;Enemy.Energy=Math.Max(0,Enemy.Energy-damage);
        if(Enemy.Energy<=0){Xp+=Enemy.Guardian?20:Enemy.Robot?30:20;if(Enemy.Guardian){Done[2]=true;guardianFight=false;}Enemy=null;}
        else EnemyReaction();
    }
    public void Escape()
    {
        if(Enemy==null)throw new InvalidOperationException("No hay nada de lo que escapar.");
        Energy=Math.Max(0,Energy-5);if(rng.Next(2)==0){if(Enemy.Guardian){Done[2]=true;guardianFight=false;}Enemy=null;LastMessage="Lograste escapar. Energía -5.";}else {LastMessage="No lograste escapar. Energía -5.";EnemyReaction();}
    }
    public string AnalyzeEntity()
    {
        if(Enemy==null)throw new InvalidOperationException("No hay ninguna entidad para analizar.");
        if(!Items.Any(x=>x.Kind=="analyzer"))throw new InvalidOperationException("Necesitas un analizador.");
        var s=$"{Enemy.Name}\nEnergía: {Enemy.Energy}\nAtaque: {Enemy.Attack}\nDefensa: {(Enemy.Robot?"activa: reduce el daño a la mitad":"normal")}";
        LastMessage="Análisis de entidad completado.";EnemyReaction();return s;
    }
    private void EnemyReaction()
    {
        if(Enemy==null)return;
        int damage=Enemy.Attack;int absorbed=Math.Min(Shield,damage);Shield-=absorbed;damage-=absorbed;Energy=Math.Max(0,Energy-damage);LastMessage += $" Contraataque: daño {damage}, escudo absorbió {absorbed}.";
    }
}
